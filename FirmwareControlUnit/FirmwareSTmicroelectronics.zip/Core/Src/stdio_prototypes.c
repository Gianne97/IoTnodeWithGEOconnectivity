/*
 * stdio_prototypes.c
 *
 *  Created on: Feb 21, 2024
 *      Author: marco
 */

#include "main.h"
#include "includes.h"

extern UART_HandleTypeDef huart2;
extern UART_HandleTypeDef huart3;
extern UART_HandleTypeDef huart5;
extern UART_HandleTypeDef huart6;

//destinazione del printf() voglio che sia sul modem
PUTCHAR_PROTOTYPE
{
  HAL_UART_Transmit(&MODEM_UART, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
  return ch;
}

//destinazione dello scanf() voglio che sia sul modulo GPS
GETCHAR_PROTOTYPE
{
  uint8_t ch = 0;

  /* Clear the Overrun flag just before receiving the first character */
  __HAL_UART_CLEAR_OREFLAG(&GPS_UART);

  /* Wait for reception of a character on the USART RX line and echo this
   * character on console */
  HAL_UART_Receive(&GPS_UART, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
  HAL_UART_Transmit(&GPS_UART, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
  return ch;
}
