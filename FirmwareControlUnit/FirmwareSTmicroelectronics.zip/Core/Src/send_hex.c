#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static inline void string_pad(char* input, const char pad, const int size) {
	int src_size = strlen(input);
	int delta = size - src_size;

	if (delta <= 0)
		return;

	memmove(input + delta, input, src_size + 1);
	while (delta > 0) {
		input[delta - 1] = pad;
		delta--;
	}
	return;
}

char* send_hex(const char *dato_dec) {
	
	const int field_len_hex[] = { 9 , 9 , 2 , 4 , 4 , 4 , 3 , 3 , 4 , 4 , 4, 4, 4, 6, 6 };
	const int offsets_dec[] = { 900000000 , 1800000000 , 0 , 10000 , 10000 , 0 , 300 , 0 , 16384 , 16384 , 16384, 0, 0, 0, 0 };
	const int campi = 15;
	
	char dato_hex[256];
	static char dato_hex_sep[256];
	char temp[20];

	int i,j, field_len_dec, num;
	int cnt_dec, cnt_hex;

	for (i = 0, cnt_dec = 0, cnt_hex = 0; i < campi; i++) {
		memset(temp, 0, sizeof(temp));
		field_len_dec = (int)(strchr(dato_dec + cnt_dec, ',') - (dato_dec + cnt_dec));

		memcpy(temp, dato_dec + cnt_dec, field_len_dec * sizeof(char));
		sscanf(temp, "%d", &num);
		num += offsets_dec[i];
		sprintf(dato_hex + cnt_hex, "%X", num);		
		string_pad(dato_hex + cnt_hex, '0', field_len_hex[i]);
		
		cnt_dec += field_len_dec + 1;
		cnt_hex += field_len_hex[i];

	}

	for (i = 0, j = 0; i < cnt_hex; i++) {
		dato_hex_sep[j] = dato_hex[i];
		j++;
		if (i % 2 != 0) {
			dato_hex_sep[j] = ':';
			j++;
		}

	}
	dato_hex_sep[j-1] = 0;	
	return dato_hex_sep;
}
