/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "string.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "includes.h"
#include <stdio.h>
#include <stdlib.h>
#include "minmea.h"
#include "MY_DHT22.h"
#include "lis3dh.h"
#include "INA219.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

//Scheda 1 ha resistore 5.52k, Scheda 2 ha 5.593k
#define SCHEDA1
//Mettere sempre numero dispari
#define COORD_LENGTH 11

#define SEND_DELTA 40000
#define MODEM_ACK_MAX 15000
#define ERR_COUNT_MAX 8
#define SINGLE_PKT

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
#if defined ( __ICCARM__ ) /*!< IAR Compiler */
#pragma location=0x2007c000
ETH_DMADescTypeDef  DMARxDscrTab[ETH_RX_DESC_CNT]; /* Ethernet Rx DMA Descriptors */
#pragma location=0x2007c0a0
ETH_DMADescTypeDef  DMATxDscrTab[ETH_TX_DESC_CNT]; /* Ethernet Tx DMA Descriptors */

#elif defined ( __CC_ARM )  /* MDK ARM Compiler */

__attribute__((at(0x2007c000))) ETH_DMADescTypeDef  DMARxDscrTab[ETH_RX_DESC_CNT]; /* Ethernet Rx DMA Descriptors */
__attribute__((at(0x2007c0a0))) ETH_DMADescTypeDef  DMATxDscrTab[ETH_TX_DESC_CNT]; /* Ethernet Tx DMA Descriptors */

#elif defined ( __GNUC__ ) /* GNU Compiler */

ETH_DMADescTypeDef DMARxDscrTab[ETH_RX_DESC_CNT] __attribute__((section(".RxDecripSection"))); /* Ethernet Rx DMA Descriptors */
ETH_DMADescTypeDef DMATxDscrTab[ETH_TX_DESC_CNT] __attribute__((section(".TxDecripSection")));   /* Ethernet Tx DMA Descriptors */
#endif

ETH_TxPacketConfig TxConfig;

ADC_HandleTypeDef hadc1;

ETH_HandleTypeDef heth;

I2C_HandleTypeDef hi2c1;
I2C_HandleTypeDef hi2c2;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart5;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;
UART_HandleTypeDef huart6;

PCD_HandleTypeDef hpcd_USB_OTG_FS;

/* USER CODE BEGIN PV */

uint8_t packet_index = 0; //0=off, 1=on
volatile uint8_t MODEM_int_triggered = 0;
volatile uint8_t GPS_int_triggered = 0;
HAL_StatusTypeDef errorlevel, status;
lis3dh_t lis3dh;

//sensore corrente
INA219_t ina219;
uint16_t config, timectr;
int16_t current;
int32_t totalCharge;


//Device's address
#define INA219_ADDRESS		(0x40)
//Define registers
#define CONFIGURATION 		0x00
#define SHUNT_VOLTAGE 		0x01
#define BUS_VOLTAGE 		0x02
#define POWER 				0x03
#define CURRENT 			0x04
#define CALIBRATION 		0x05


uint8_t xyz_buf[6] = { 0 };
unsigned int sens_rad = 0;
static long int  lati, longi;
static int sats, alti, heig, tempe = 0, humi = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_USB_OTG_FS_PCD_Init(void);
static void MX_USART6_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
static void MX_ETH_Init(void);
static void MX_UART5_Init(void);
static void MX_ADC1_Init(void);
static void MX_I2C2_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM3_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

// Comparison function
static inline int compare(const void* a, const void* b) {
   return (*(int*)a - *(int*)b);
}

static void start_join() {
//INIZIO PROCEDURA DI JOIN
	int count;
	int join_found;
	static char int_led = 0;
	uint8_t receive_buffer[256], dump_buffer[256];

	HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, 0);
	HAL_GPIO_WritePin(LD3_GPIO_Port, LD3_Pin, 0);
	  do {
	  		count = 0;
			join_found = 0;

			HAL_NVIC_DisableIRQ(TIM3_IRQn);
	  		HAL_UART_Transmit(&MODEM_UART, JOIN_COMM, sizeof(JOIN_COMM), 1000);
	  		HAL_NVIC_EnableIRQ(TIM3_IRQn);

	  		HAL_Delay(5000);	//Attende completamento stampa successiva al comando JOIN

	  		HAL_NVIC_DisableIRQ(TIM3_IRQn);
	  		while ( (errorlevel = HAL_UART_Receive(&MODEM_UART, dump_buffer, sizeof(dump_buffer), 20)) == HAL_OK) {
	  			__NOP();	//purge uart rx
	  		}
	  		HAL_NVIC_EnableIRQ(TIM3_IRQn);

	  		do {
	  			//Inizio procedura Join
	  			//Azzero dump buffer, elimina eventuali dati vecchi.
	  			memset(dump_buffer,0 ,sizeof(dump_buffer));
	  			memset(receive_buffer,0 ,sizeof(receive_buffer));
	  			HAL_UART_AbortReceive(&MODEM_UART);
	  			MODEM_int_triggered = 0;
	  			HAL_UART_Receive_IT (&MODEM_UART, dump_buffer, 1);

//	  			HAL_NVIC_DisableIRQ(TIM3_IRQn);
	  			while ( MODEM_int_triggered == 0) {
	  				__NOP();	//Attendo un carattere in ingresso
	  			}
	  			HAL_NVIC_DisableIRQ(TIM3_IRQn);
	  			while ( (errorlevel = HAL_UART_Receive(&MODEM_UART, dump_buffer+1, sizeof(dump_buffer)-1, 20)) == HAL_OK) {
	  				__NOP();	//Blocca fino a quando non ho acquisito una stringa completa dall'UART
	  			}
	  			HAL_NVIC_EnableIRQ(TIM3_IRQn);

	  			if (int_led == 0) {
					HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, 1);
					int_led = 1;
				}
				else {
					HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, 0);
					int_led = 0;
				}

	  			//Eseguo controllo solo su stringhe di failure
	  			if  (strstr((char*)dump_buffer,"failed") != NULL) {
	  				HAL_NVIC_DisableIRQ(TIM3_IRQn);
	  				HAL_UART_Transmit(&MODEM_UART, JOIN_STAT_COMM, sizeof(JOIN_STAT_COMM), 1000);
	  				HAL_UART_Receive(&MODEM_UART, receive_buffer, sizeof(receive_buffer), 20);
	  				//Controllo se il risultato di NJS contiene '1'
	  				count++;
	  				HAL_NVIC_EnableIRQ(TIM3_IRQn);
	  			}
	  			else if (strstr((char*)dump_buffer,"joined") != NULL) {
	  				//Qui sono connesso, posso uscire da entrambi i loop
	  				HAL_NVIC_DisableIRQ(TIM3_IRQn);
	  				join_found = 1;
	  				HAL_UART_Transmit(&MODEM_UART, JOIN_STAT_COMM, sizeof(JOIN_STAT_COMM), 1000);
	  				HAL_UART_Receive(&MODEM_UART, receive_buffer, sizeof(receive_buffer), 20);
	  				HAL_NVIC_EnableIRQ(TIM3_IRQn);
	  			}
	  		} while ( (strstr((char*)receive_buffer, "NJS:1") == NULL) && (count <8) && (join_found == 0));
	  		 //HAL_Delay(5000);
	  	} while( (strstr((char*)receive_buffer, "NJS:1") == NULL) && (join_found == 0));
	  	//Qui il JOIN ha avuto successo, attendere 1 minuto per aggancio Clock
	  	HAL_GPIO_WritePin(LD3_GPIO_Port, LD3_Pin, 1);
	  	HAL_GPIO_WritePin(Light_sens_drv_GPIO_Port, Light_sens_drv_Pin, 1);

}

static int modem_send(const char *message) {

	int err_count = 0;
	int success_found = 0;
	uint8_t dump_buffer[256];
	uint32_t timestamp_old, timestamp_new, timestamp_delta;

	HAL_NVIC_DisableIRQ(TIM3_IRQn);
	while ( (errorlevel = HAL_UART_Receive(&MODEM_UART, dump_buffer, sizeof(dump_buffer), 20)) == HAL_OK) {
	  	__NOP();	//purge uart rx
	}
	HAL_UART_AbortReceive(&MODEM_UART);

	do {

#ifdef SINGLE_PKT
	  		printf("AT+SENDB=1,0,8,1,%s\r\n", message);
#else
	  		printf("%s", message);
#endif

	  		HAL_NVIC_EnableIRQ(TIM3_IRQn);
	  		//Controllo la risposta, se errore ripeto per 3 volte
			//Azzero dump buffer, elimina eventuali dati vecchi.
			memset(dump_buffer,0 ,sizeof(dump_buffer));
			HAL_UART_AbortReceive(&MODEM_UART);
			MODEM_int_triggered = 0;
			HAL_UART_Receive_IT (&MODEM_UART, dump_buffer, 1);
			while ( MODEM_int_triggered == 0) {
				__NOP();	//Attendo un carattere in ingresso
			}

			HAL_NVIC_DisableIRQ(TIM3_IRQn);
			while ( (errorlevel = HAL_UART_Receive(&MODEM_UART, dump_buffer+1, sizeof(dump_buffer)-1, 20)) == HAL_OK) {
				__NOP();	//Blocca fino a quando non ho acquisito una stringa completa dall'UART
			}
			HAL_NVIC_EnableIRQ(TIM3_IRQn);

			//Se è busy, attendo un secondo e ripeto all'infinito
			if  (strstr((char*)dump_buffer,"Busy") != NULL) {
				HAL_Delay(2000);
			}
			else if (strstr((char*)dump_buffer,"QUEUED") != NULL) {
				success_found = 1;

			}
			else {
				//Qui non ho trasmesso, potrebbe essersi disconnessa la scheda
				//ripeto più volte e poi richiamo il join se necessario
				err_count++;
				HAL_Delay(5000);

			}

	} while( (err_count < ERR_COUNT_MAX) && (success_found == 0));

	//Dump RX buffer
	HAL_NVIC_DisableIRQ(TIM3_IRQn);
	while ( (errorlevel = HAL_UART_Receive(&MODEM_UART, dump_buffer, sizeof(dump_buffer), 20)) == HAL_OK) {
	  	__NOP();	//purge uart rx
	}
	HAL_UART_AbortReceive(&MODEM_UART);
	MODEM_int_triggered = 0;
	HAL_NVIC_EnableIRQ(TIM3_IRQn);

	if (success_found == 0) {
		//Arrivo qui senza il messaggio in queue,
		//Segnalo che bisogna ripetere il join
		return -1;
	}

	HAL_Delay(500);
	memset(dump_buffer,0 ,sizeof(dump_buffer));
	HAL_UART_AbortReceive(&MODEM_UART);
	MODEM_int_triggered = 0;
	//Se arrivo qui il messaggio è in queue, ma devo controllare se è stato inviato
	//Cancello tutto il resto nel buffer RX per esaminare risposta dal modem
	//Se non ricevo nulla dopo un certo tempo, ripeto l'invio del messaggio per non bloccare tutto
	HAL_UART_Receive_IT (&MODEM_UART, dump_buffer, 1);

//	HAL_NVIC_DisableIRQ(TIM3_IRQn);
	timestamp_old = HAL_GetTick();
	while ( MODEM_int_triggered == 0) {
		//Attendo un carattere in ingresso
		timestamp_new = HAL_GetTick();
		timestamp_delta = timestamp_new - timestamp_old;
		HAL_Delay(1);
		if (timestamp_delta > MODEM_ACK_MAX) {
//			HAL_NVIC_EnableIRQ(TIM3_IRQn);
			return modem_send(message);
		}
	}
	HAL_NVIC_DisableIRQ(TIM3_IRQn);
	while ( (errorlevel = HAL_UART_Receive(&MODEM_UART, dump_buffer+1, sizeof(dump_buffer)-1, 20)) == HAL_OK) {
		__NOP();	//Blocca fino a quando non ho acquisito una stringa completa dall'UART
	}
	HAL_NVIC_EnableIRQ(TIM3_IRQn);

	if  (strstr((char*)dump_buffer,"NOT_SENT") != NULL) {
		//Il pacchetto è andato perso, devo ripetere l'invio
		//Richiamo iterativamente la funzione
		memset(dump_buffer,0 ,sizeof(dump_buffer));
		HAL_UART_AbortReceive(&MODEM_UART);
		MODEM_int_triggered = 0;

		return modem_send(message);
	}
	else {
		memset(dump_buffer,0 ,sizeof(dump_buffer));
		HAL_UART_AbortReceive(&MODEM_UART);
		MODEM_int_triggered = 0;

		return 0;
	}

}

static inline void whole_read(void) {
	struct minmea_sentence_gga frame_gga;
	unsigned char gga_ok;
	char line[MINMEA_MAX_SENTENCE_LENGTH];
	double temp;
	long int longi_arr[COORD_LENGTH], lati_arr[COORD_LENGTH];
	int alti_arr[COORD_LENGTH], heig_arr[COORD_LENGTH], sats_arr[COORD_LENGTH];
	int coord_cnt = 0;
	float TempC, Humidity;
	int cnt;

	do{
		gga_ok = 0;
		do {
			memset(line, 0 ,sizeof(line));
			if (HAL_GPIO_ReadPin(GPS_Debug_GPIO_Port, GPS_Debug_Pin) == 0) {
				//Messaggi preconfezionati GPS, utili nel caso mancata connessione
				if (gga_ok == 0) {
					memcpy(line,"$GNGGA,060406.00,4337.20081,N,01128.50427,E,1,09,1.05,133.6,M,45.2,M,,*57",sizeof("$GNGGA,060406.00,4337.20081,N,01128.50427,E,1,09,1.05,133.6,M,45.2,M,,*57"));
				}
			}
			else {

				//Acquisisco dal GPS, se presente
				HAL_NVIC_EnableIRQ(TIM3_IRQn);
				memset(line,0 ,sizeof(line));
				HAL_UART_AbortReceive(&GPS_UART);
//				GPS_int_triggered = 0;
//				HAL_NVIC_ClearPendingIRQ(USART2_IRQn);
//				HAL_NVIC_EnableIRQ(USART2_IRQn);
				do {
					line[0] = 0;
					HAL_NVIC_EnableIRQ(TIM3_IRQn);
					HAL_UART_Receive (&GPS_UART, (uint8_t*)line, 1, 10);
					HAL_NVIC_DisableIRQ(TIM3_IRQn);
				}while(line[0] != '$');
//				while ( GPS_int_triggered == 0) {
//					__NOP();	//Attendo un carattere in ingresso
//				}

				//SEZIONE CRITICA
//				HAL_NVIC_DisableIRQ(TIM3_IRQn);


				//RICEVE TUTTO SENZA FERMARSI
//				while (fgets(line+1, sizeof(line-1), stdin) == NULL) {}
				cnt = 1;
				do {
					HAL_UART_Receive (&GPS_UART, ((uint8_t*)line)+cnt, 1, 10);
					cnt++;
				}while( (line[cnt] != '\n') && (cnt <80) && (line[cnt] != '$'));



				HAL_NVIC_EnableIRQ(TIM3_IRQn);
//				HAL_NVIC_DisableIRQ(USART2_IRQn);
//				HAL_NVIC_ClearPendingIRQ(USART2_IRQn);
			}
			switch (minmea_sentence_id(line, false)) {
				//mi servono soltanto le parole GGA
				case MINMEA_SENTENCE_GGA: {
					if (minmea_parse_gga(&frame_gga, line)) {
					  lati = minmea_rescale(&frame_gga.latitude, 100000);
					  longi = minmea_rescale(&frame_gga.longitude, 100000);
					  alti = minmea_rescale(&frame_gga.altitude, 10);
					  heig = minmea_rescale(&frame_gga.height, 10);
					  sats = frame_gga.satellites_tracked;
					  if ( (alti != 0) && (heig != 0) && (sats != 0) && (lati != 0) && (longi != 0) )
						  gga_ok = 1;
					  else
						  gga_ok = 0;
					}
				} break;

				default: {
					//Non fa nulla, attendi stringa giusta
				} break;

			}

		}while ( gga_ok == 0 );
		//Ho acquisito coordinate valide, le inserisco nel buffer per la mediana
		lati_arr[coord_cnt] = lati;
		longi_arr[coord_cnt] = longi;
		alti_arr[coord_cnt] = alti;
		heig_arr[coord_cnt] = heig;
		sats_arr[coord_cnt] = sats;

		coord_cnt++;

	}while(coord_cnt < COORD_LENGTH);

	//A questo punto prendo la mediana delle coordinate
	qsort(lati_arr, COORD_LENGTH, sizeof(long int), compare);
	qsort(longi_arr, COORD_LENGTH, sizeof(long int), compare);
	qsort(alti_arr, COORD_LENGTH, sizeof(int), compare);
	qsort(heig_arr, COORD_LENGTH, sizeof(int), compare);
	qsort(sats_arr, COORD_LENGTH, sizeof(int), compare);

	lati = lati_arr[COORD_LENGTH/2];
	longi = longi_arr[COORD_LENGTH/2];
	alti = alti_arr[COORD_LENGTH/2];
	heig = heig_arr[COORD_LENGTH/2];
	sats = sats_arr[COORD_LENGTH/2];

	//Il GPS acquisito, Ora passo ad altri sensori

	do{
		HAL_NVIC_DisableIRQ(TIM3_IRQn);
		if(DHT22_GetTemp_Humidity(&TempC, &Humidity) == 1)
			  {
				HAL_NVIC_EnableIRQ(TIM3_IRQn);
				tempe = (uint32_t)(TempC*10.0);
				humi = (uint32_t)(Humidity*10.0);
				break;
			  }
		else {
			HAL_NVIC_EnableIRQ(TIM3_IRQn);
		}
		HAL_Delay(500);
	}while (1);

	do{
		if (lis3dh_xyz_available(&lis3dh)) {
			status = lis3dh_get_xyz(&lis3dh);
			// You now have raw acceleration of gravity in lis3dh->x, y, and z.
			break;
		}
		HAL_Delay(10);
	}while(1);

	HAL_ADC_Start(&hadc1);
	HAL_ADC_PollForConversion(&hadc1, 10);
	HAL_ADC_GetValue(&hadc1);
	sens_rad = HAL_ADC_GetValue(&hadc1);

#ifdef SCHEDA1
	temp = ((double)(4096-sens_rad))*7.589588995;
#else
	temp = ((double)(4096-sens_rad))*7.490529456;
#endif

	sens_rad = (unsigned int)(temp);

}

//TMR3 INTERRUPT


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

	char line[128];
	uint32_t timestamp_old, timestamp_new, timestamp_delta;
	uint8_t first_iter = 0;
	int count;
#ifndef SINGLE_PKT
	unsigned int conta_msg = 0;
#endif

	int32_t totalCharge_old = 0, totalCharge_sleep_old = 0;
	uint16_t timectr_old = 0, timectr_sleep_old = 0;


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART3_UART_Init();
  MX_USB_OTG_FS_PCD_Init();
  MX_USART6_UART_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  MX_ETH_Init();
  MX_UART5_Init();
  MX_ADC1_Init();
  MX_I2C2_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */

  totalCharge = 0;
  timectr = 0;

  //Avvio Timer3
  if (HAL_TIM_Base_Start_IT(&htim3) != HAL_OK)
  {
  /* Starting Error */
  Error_Handler();
  }

  DHT22_Init(sens_temp_GPIO_Port, sens_temp_Pin);

  //Inizializzazione Accelerometro
  for(count = 0; count <3; count++) {
	  status = lis3dh_init(&lis3dh, &hi2c1, xyz_buf, 6);
	  if (status != HAL_OK) { // Unable to communicate with device!
		  HAL_Delay(1000);
	  }
	  else {
		  goto accel_ok;
	  }
  }
	//Se arriva qui blocca tutto per errore di comunicazione I2C
	HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, 1);
	while(1) {}

	accel_ok:
	HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, 1);
	HAL_Delay(500);
	HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, 0);
	HAL_Delay(500);

	//abilitazione INA
	while(!INA219_Init(&ina219, &hi2c2, INA219_ADDRESS))
	{
		//attendi inizializzazione INA

		HAL_UART_Transmit(&PC_UART, INA_ERR_MSG, sizeof(INA_ERR_MSG), 1000);
		HAL_Delay(100);

	}

	uint16_t config = INA219_CONFIG_BVOLTAGERANGE_16V |
						INA219_CONFIG_GAIN_1_40MV | INA219_CONFIG_BADCRES_12BIT |
						INA219_CONFIG_SADCRES_12BIT_1S_532US |
						INA219_CONFIG_MODE_SANDBVOLT_CONTINUOUS;
	INA219_setConfig(&ina219, config);


	HAL_NVIC_DisableIRQ(TIM3_IRQn);

  	//Reset e Abilitazione LoRa
  	HAL_GPIO_WritePin(LD3_GPIO_Port, LD3_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(CTS_MODEM_GPIO_Port, CTS_MODEM_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(RTS_MODEM_GPIO_Port, RTS_MODEM_Pin, GPIO_PIN_SET);
	HAL_Delay(500);
	HAL_GPIO_WritePin(OEM_RST_GPIO_Port, OEM_RST_Pin, GPIO_PIN_RESET);

	HAL_Delay(500);

	HAL_GPIO_WritePin(RTS_MODEM_GPIO_Port, RTS_MODEM_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(CTS_MODEM_GPIO_Port, CTS_MODEM_Pin, GPIO_PIN_RESET);

	//Metto CTS da input ad output per 1ms
	GPIOF->MODER |= GPIO_MODER_MODER3_0;
	//HAL_GPIO_WritePin(RTS_MODEM_GPIO_Port, RTS_MODEM_Pin, GPIO_PIN_RESET);

	HAL_Delay(10);
	HAL_GPIO_WritePin(OEM_RST_GPIO_Port, OEM_RST_Pin, GPIO_PIN_SET);
	GPIOF->MODER &= ~(GPIO_MODER_MODER3);
	//HAL_Delay(1);
	HAL_GPIO_WritePin(CTS_MODEM_GPIO_Port, CTS_MODEM_Pin, GPIO_PIN_SET);

	HAL_NVIC_EnableIRQ(TIM3_IRQn);


	//PARTO CON PROCEDURA DI JOIN
	HAL_GPIO_WritePin(Light_sens_drv_GPIO_Port, Light_sens_drv_Pin, 0);
	start_join();
	HAL_Delay(1000);

	//SLEEP MODEM
	HAL_NVIC_DisableIRQ(TIM3_IRQn);
	HAL_GPIO_WritePin(RTS_MODEM_GPIO_Port, RTS_MODEM_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(CTS_MODEM_GPIO_Port, CTS_MODEM_Pin, GPIO_PIN_SET);
	HAL_NVIC_EnableIRQ(TIM3_IRQn);
	//FINE SLEEP MODEM

	HAL_Delay(1000);
	//PULIZIA PRIMA DI INIZIARE IL LOOP
	totalCharge_old = 0;
	timectr_old = 0;
	totalCharge = 0;
	timectr = 0;
	totalCharge_sleep_old = 0;
	timectr_sleep_old = 0;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	  //Leggo gruppo sensori, il modem è in stato sleep qui
	  whole_read();

//PARTE CRITICA

		if (packet_index != 0) { //invio

		//RIATTIVA MODEM
			HAL_NVIC_DisableIRQ(TIM3_IRQn);
			HAL_GPIO_WritePin(RTS_MODEM_GPIO_Port, RTS_MODEM_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(CTS_MODEM_GPIO_Port, CTS_MODEM_Pin, GPIO_PIN_RESET);

			//Metto CTS da input ad output per 1ms
			GPIOF->MODER |= GPIO_MODER_MODER3_0;
			//HAL_GPIO_WritePin(RTS_MODEM_GPIO_Port, RTS_MODEM_Pin, GPIO_PIN_RESET);

			HAL_Delay(10);
			GPIOF->MODER &= ~(GPIO_MODER_MODER3);
			//HAL_Delay(1);
			HAL_GPIO_WritePin(CTS_MODEM_GPIO_Port, CTS_MODEM_Pin, GPIO_PIN_SET);
			HAL_NVIC_EnableIRQ(TIM3_IRQn);
		//FINE RIATTIVA MODEM

			//A questo punto ho tutti i dati pronti, posso inviarli
			memset(line, 0 ,sizeof(line));
			sprintf(line, "%09ld,%010ld,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%ld,%ld,", lati, longi, sats, alti, heig, sens_rad, tempe, humi, lis3dh.x, lis3dh.y, lis3dh.z, timectr_sleep_old, timectr_old, totalCharge_sleep_old, totalCharge_old);
			HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, 1);

			while (modem_send(send_hex(line)) == -1)
				start_join();
			HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, 0);


		//SLEEP MODEM
			HAL_NVIC_DisableIRQ(TIM3_IRQn);
			HAL_GPIO_WritePin(RTS_MODEM_GPIO_Port, RTS_MODEM_Pin, GPIO_PIN_SET);
			HAL_GPIO_WritePin(CTS_MODEM_GPIO_Port, CTS_MODEM_Pin, GPIO_PIN_SET);
			HAL_NVIC_EnableIRQ(TIM3_IRQn);
		//FINE SLEEP MODEM


//			packet_index = 0;
		}
		else { //non invio, memorizzo soltanto i valori sleep per inviarli nel prox


//			totalCharge = 0;
//			timectr = 0;

//			packet_index = 1;
		}


//FINE PARTE CRITICA


	//Ritarda quanto basta per inviare ogni 60sec
	//se era la prima volta, bypasso
	if (first_iter == 0) {
		timestamp_old = HAL_GetTick();
		first_iter = 1;
	}
	else {
		do {
			timestamp_new = HAL_GetTick();
			timestamp_delta = timestamp_new - timestamp_old;
			HAL_Delay(10);
		}while ( timestamp_delta < SEND_DELTA );
		timestamp_old = timestamp_new;
	}

	//RESET CONTATORI per PROX CICLO

	if (packet_index != 0) { //invio
		timectr_old = timectr;
		totalCharge_old = totalCharge;
		packet_index = 0;
	}
	else {
		timectr_sleep_old = timectr;
		totalCharge_sleep_old = totalCharge;
		packet_index = 1;
	}

	totalCharge = 0;
	timectr = 0;


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 96;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief ETH Initialization Function
  * @param None
  * @retval None
  */
static void MX_ETH_Init(void)
{

  /* USER CODE BEGIN ETH_Init 0 */

  /* USER CODE END ETH_Init 0 */

   static uint8_t MACAddr[6];

  /* USER CODE BEGIN ETH_Init 1 */

  /* USER CODE END ETH_Init 1 */
  heth.Instance = ETH;
  MACAddr[0] = 0x00;
  MACAddr[1] = 0x80;
  MACAddr[2] = 0xE1;
  MACAddr[3] = 0x00;
  MACAddr[4] = 0x00;
  MACAddr[5] = 0x00;
  heth.Init.MACAddr = &MACAddr[0];
  heth.Init.MediaInterface = HAL_ETH_RMII_MODE;
  heth.Init.TxDesc = DMATxDscrTab;
  heth.Init.RxDesc = DMARxDscrTab;
  heth.Init.RxBuffLen = 1524;

  /* USER CODE BEGIN MACADDRESS */

  /* USER CODE END MACADDRESS */

  if (HAL_ETH_Init(&heth) != HAL_OK)
  {
    Error_Handler();
  }

  memset(&TxConfig, 0 , sizeof(ETH_TxPacketConfig));
  TxConfig.Attributes = ETH_TX_PACKETS_FEATURES_CSUM | ETH_TX_PACKETS_FEATURES_CRCPAD;
  TxConfig.ChecksumCtrl = ETH_CHECKSUM_IPHDR_PAYLOAD_INSERT_PHDR_CALC;
  TxConfig.CRCPadCtrl = ETH_CRC_PAD_INSERT;
  /* USER CODE BEGIN ETH_Init 2 */

  /* USER CODE END ETH_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x20303E5D;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.Timing = 0x302095F7;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c2, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c2, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 95;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 5000;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief UART5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART5_Init(void)
{

  /* USER CODE BEGIN UART5_Init 0 */

  /* USER CODE END UART5_Init 0 */

  /* USER CODE BEGIN UART5_Init 1 */

  /* USER CODE END UART5_Init 1 */
  huart5.Instance = UART5;
  huart5.Init.BaudRate = 115200;
  huart5.Init.WordLength = UART_WORDLENGTH_8B;
  huart5.Init.StopBits = UART_STOPBITS_1;
  huart5.Init.Parity = UART_PARITY_NONE;
  huart5.Init.Mode = UART_MODE_TX_RX;
  huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart5.Init.OverSampling = UART_OVERSAMPLING_16;
  huart5.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart5.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart5) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART5_Init 2 */

  /* USER CODE END UART5_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief USART6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART6_UART_Init(void)
{

  /* USER CODE BEGIN USART6_Init 0 */

  /* USER CODE END USART6_Init 0 */

  /* USER CODE BEGIN USART6_Init 1 */

  /* USER CODE END USART6_Init 1 */
  huart6.Instance = USART6;
  huart6.Init.BaudRate = 115200;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_TX_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  huart6.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart6.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart6) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART6_Init 2 */

  /* USER CODE END USART6_Init 2 */

}

/**
  * @brief USB_OTG_FS Initialization Function
  * @param None
  * @retval None
  */
static void MX_USB_OTG_FS_PCD_Init(void)
{

  /* USER CODE BEGIN USB_OTG_FS_Init 0 */

  /* USER CODE END USB_OTG_FS_Init 0 */

  /* USER CODE BEGIN USB_OTG_FS_Init 1 */

  /* USER CODE END USB_OTG_FS_Init 1 */
  hpcd_USB_OTG_FS.Instance = USB_OTG_FS;
  hpcd_USB_OTG_FS.Init.dev_endpoints = 6;
  hpcd_USB_OTG_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_OTG_FS.Init.dma_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
  hpcd_USB_OTG_FS.Init.Sof_enable = ENABLE;
  hpcd_USB_OTG_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.vbus_sensing_enable = ENABLE;
  hpcd_USB_OTG_FS.Init.use_dedicated_ep1 = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_OTG_FS) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_OTG_FS_Init 2 */

  /* USER CODE END USB_OTG_FS_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(OEM_RST_GPIO_Port, OEM_RST_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(RTS_MODEM_GPIO_Port, RTS_MODEM_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LD1_Pin|LD3_Pin|Light_sens_drv_Pin|LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOG, GPIO_PIN_6, GPIO_PIN_RESET);

  /*Configure GPIO pin : USER_Btn_Pin */
  GPIO_InitStruct.Pin = USER_Btn_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(USER_Btn_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : CTS_MODEM_Pin GPS_LNA_Pin */
  GPIO_InitStruct.Pin = CTS_MODEM_Pin|GPS_LNA_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pin : OEM_RST_Pin */
  GPIO_InitStruct.Pin = OEM_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(OEM_RST_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : RTS_MODEM_Pin */
  GPIO_InitStruct.Pin = RTS_MODEM_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(RTS_MODEM_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LD1_Pin LD3_Pin Light_sens_drv_Pin LD2_Pin */
  GPIO_InitStruct.Pin = LD1_Pin|LD3_Pin|Light_sens_drv_Pin|LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : GPS_Debug_Pin */
  GPIO_InitStruct.Pin = GPS_Debug_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPS_Debug_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PG6 */
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /*Configure GPIO pin : PG7 */
  GPIO_InitStruct.Pin = GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /*Configure GPIO pin : sens_temp_Pin */
  GPIO_InitStruct.Pin = sens_temp_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(sens_temp_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if ( huart == &MODEM_UART)
		MODEM_int_triggered = 1;
//	else
//		GPS_int_triggered = 1;
	return;
	//HAL_UART_Receive_IT(&MODEM_UART, dump_buffer+1, sizeof(dump_buffer)-1);
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
