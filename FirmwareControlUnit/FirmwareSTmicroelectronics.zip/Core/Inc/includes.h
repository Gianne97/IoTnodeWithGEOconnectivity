/*
 * includes.h
 *
 *  Created on: Feb 21, 2024
 *      Author: marco
 */

#ifndef INC_INCLUDES_H_
#define INC_INCLUDES_H_

#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#define GETCHAR_PROTOTYPE int __io_getchar()
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#define GETCHAR_PROTOTYPE int fgetc(FILE *f)
#endif

#define INDENT_SPACES "  "

#define GPS_UART	huart2
#define MODEM_UART	huart5
#define PC_UART		huart6

char* send_hex(const char *dato_dec);

#endif /* INC_INCLUDES_H_ */

static const uint8_t JOIN_COMM[] = {"\r\nAT+JOIN\r\n"};
static const uint8_t JOIN_STAT_COMM[] = {"\r\nAT+NJS?\r\n"};
static const uint8_t INA_ERR_MSG[] = {"INA Errore\r\n"};
